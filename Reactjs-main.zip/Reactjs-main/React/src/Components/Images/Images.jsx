import { React } from 'react'


const Images = ({value}) => {
    return(
        <div>
            <img src={value}/>
        </div>
    )
}

export default Images;
