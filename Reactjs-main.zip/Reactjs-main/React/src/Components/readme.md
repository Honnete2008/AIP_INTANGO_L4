# Arrow function

1. Make 2 functions (arrow & normal) and make them display 2 different data

2. Pass arguments and show the difference



# Props:

1. Pass the Props component to App.jsx and make name prop dynamic. (First display 3 duplicates, then make name dynamic)


# Hooks

1. Usestate: Increment and decrement example