import React from 'react'
import '../App.css'

function Part3() {

  return (
    <div className='footer-container'>
      <a href="">
        <i class="fa-brands fa-linkedin-in"></i>
      </a>
      <a href="">
        <i class="fa-brands fa-behance"></i>
      </a>
      <a href="">
        <i class="fa-brands fa-github"></i>
      </a>
    </div>
  )
}


export default Part3
