import { React } from 'react'

function Props(value) {
    
  return (
    <h1>Hello, Im {value.name}</h1>
  );
}

export default Props;
