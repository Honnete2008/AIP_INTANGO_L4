# IntangoServer

## Content summary

1. Remember to keep your api key in env file
2. Once started using glitch, check in my codes for dependencies.json. Use the same dependencies you find there




Sources:
- https://www.w3schools.com/nodejs/default.asp
- https://www.freecodecamp.org/learn/back-end-development-and-apis/#basic-node-and-express