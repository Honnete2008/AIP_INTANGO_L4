# Reactjs
Introduction to react


## COURSE OUTLINE


1.	Installation with vite
2.	Camel case instructions

3.	Intro to ES6 
    - Arrow functions 
    - Destructuring 
    - Spread operators
    - Ternary operators (Manage submit button from our portfolio)

4.	Props
5.	Events (onClick, onChange, onSubmit)
6.	React routers
7.	Hooks
8.	useState
9.	useEffect

